from utils import newline

print(5/2,5//2,5%2,5**2)

newline()

age = 30

if age>30 and age < 35:
    print("Get your priorities right!!")
else:
    print("Take your time exploring the world")    

newline()    

isCitizen=False

if not isCitizen:
    print("You need Visa")
else:
    print("You are fine!")    

newline()    

a_list=[1,2,3]

if 1 in a_list:
    print("1 is there!")


name="Alice"

if "A" in name:
    print("Character A found!")


newline()

a = 20
b = 30

print(id(a), id(b))

if a is b:
    print("a is b")
else:
    print("a is not b")    

newline()

for letter in "Python":
    if letter is "o":
        pass
    else:
        print(letter)


newline()

# user_name=input("What is your name:")
# print(f"you said your name is {user_name}")

name="johny"

print(len(name))
print(name.capitalize())
print(name.upper())
print(name.isdecimal())

newline()

a_list=[1,2,3,4,5,6,1]

print(f"1 occurs {a_list.count(1)} times")

a_list.append(7)

print(a_list)

a_list.sort()
print(a_list)

newline()


print(type(a_list))

class Car:
    num_of_wheels=4

    def __init__(self,model,year):
        self.model= model
        self.year=year
        

    def run(self,speed):
        print(f"The car {self.model} is running at {speed} km/h")

corolla = Car("Corolla",2026)

corolla.run(100)

print(f"most cars have {corolla.num_of_wheels} wheels")

print(Car.num_of_wheels)

newline()

class Person:
    def __init__(self,name:str):
        self.name=name

class Employee(Person):
    def __init__(self,employee_name:str,employee_id:int):
        super().__init__(employee_name)
        self.employee_id=employee_id

    def print_details(self):
        print(f"Employee Name {self.name} Employee Id {self.employee_id}")


emp1=Employee("Bob",100)

emp1.print_details()