echo "Ths shell script $0 is running input is $1"
echo "Great!"

if [[ $1 == "Y" ]]
then
    for i in {1..5} 
    do
        echo $i
        sleep 1
    done
fi