from utils import newline


print("hello world")

import logging

logging.basicConfig(level=logging.DEBUG)

logging.info("information - user logged in !")
logging.debug("debug - user logged in !")
logging.warning("warn - user logged in !")

# defining a function that does something!
def print_greeting():
    print("-----")
    print("hello!")
    print("how are you?")


print_greeting()


def say_hello(name:str):
    """
    This function says hello to someone
    and you can say their name
    """
    print("Hello "+ name)
    print(f"Hello {name}")


say_hello("Bob")    




total:int = 100


if total > 10:
    print(f"total {total} is greater than 10")
    print("yay")
else:
    print("total is less than 10")
    print("nay!")


newline()


print(type(total))
newline()
name:str = "Bob"
age = 30
isEmployed=True
height=5.3

print(type(name), type(isEmployed), type(height),type(age))

newline()

person=(name,age,isEmployed,height)
print(person)
print(type(person))

newline()


def add (x,y):
    return x+y

print(f"The output of 5+3 is = {add(5,3)}")    

newline()


def return_employee_info(empId:int):
    return empId,"Bob"


print(f"The output is => {return_employee_info(100)} and the type is {type(return_employee_info(100))}")

emp_id,emp_name = return_employee_info(100)

print(emp_id,emp_name)

newline()

employee_info=return_employee_info(100)

print("The output of positional access - ",employee_info[0],employee_info[1])

newline()


a_list=[1,2,3,4,5]

print(a_list)

print(a_list[0])


newline()

del(a_list)

try:
    print(a_list)
except NameError as e:
    print(f"Exception occured {e}, may be you deleted it")
finally:
    print("This always prints") 

print("more stuff")
print("even more stuff")


newline()

a_list=[1,2,3,4,5]
another_list=[10,"c",1.5]
   

print(a_list)
print(another_list)

print(f"first element of the list {a_list[0]}, last element of the list {a_list[-1]}, {a_list[1:3]}")

newline()

for i in another_list:
    print(i)

newline()

x=range(5)

print(x)
newline()
for i in x:
    print(i)

newline()

for i in range(1,5):
    print(i)

newline()

# tuple = (), list = [], dict = {}

a_dict={"name":"Bob","age":30}

print(a_dict)

newline()
employee= {"name":"Bob","age":30,"height":5.3}

print(employee)
print(employee["name"])
print(employee.get("height"))



