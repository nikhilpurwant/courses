import datetime
import pytz

# 1. Define timezones
eastern = pytz.timezone('US/Eastern')
india = pytz.timezone('Asia/Kolkata')

# 2. Localize a naive datetime (current time in Eastern)
loc_dt = eastern.localize(datetime.datetime.now())
print("Eastern Time:", loc_dt.strftime('%Y-%m-%d %H:%M:%S %Z%z'))

# 3. Convert to another timezone (India)
india_dt = loc_dt.astimezone(india)
print("India Time:", india_dt.strftime('%Y-%m-%d %H:%M:%S %Z%z'))
