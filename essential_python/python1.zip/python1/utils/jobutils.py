def newline():
    print("---------------")